#include <iostream>
using namespace std; 

class  figure
{
    public:
    float  F = 1000; 
    float area(){ return F; }
    figure(float p) { F = p; }
};

// square inherits figure data and methods. 
class square : figure  
{
    public:
    float  S = 4;
    float area() { return pow(S,2) + F; }
    square(float p1, float p2) : figure(p1) { S = p1; }
};

// line inherits figure data and methods. 
class line : figure
{
    public:
    float  L = 5;
    float area() { return L + F; }
    line(float p) : figure(p) { L = p; }
};

class Abstract
{
public:
    virtual void area() = 0; 
};

// Polymorphism, inheritance and method overriding 
// method area() of figure class is overrided 
void polymorphism()
{
     figure F(1000.);
     line L(100.); 
     square S(1000., 10000.);
     

   //  Abstract *p = new figure();; 
     float *Figures[2]; 
     float a =111, b=222; 

     Figures[0] = &a; 
     Figures[1] = &b;
      
     printf(" Example of polymorphism \n "); 
     cout << "Total area =" << L.area()+S.area()+L.area()+F.area()<<"\n";
     cout << "Figures Total area =" << *Figures[0]+*Figures[1] << "\n"; ;
}; 
