
#include "roots.h"
#include "polymorphism.h"
#include "first_class_functions.h"
#include "pointers.h"
#include "overloading.h"
#include "map_filter_reduce.h"

#include <iostream>


int main()
{
    roots(); 

    polymorphism(); 

    function_examples(); 

    test_pointers(); 

    test_overloading(); 

    test_map_filter_reduce(); 
}
