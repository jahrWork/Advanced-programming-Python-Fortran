
#include "overloading.h"
#include <iostream>
using namespace std;


// One function works for all data types.  This would work 
// even for user defined types if operator '>' is overloaded 
template <typename T> T myMax(T x, T y)
{
    return (x > y) ? x : y;
}

// Function template 
template <class T> T max(T x, T y)
{
    if (x > y) return x;
    else       return y;
}




// Function template 
template<class T> T add(T &a, T &b)
{
    T result = a + b;
    return result;

}

// Function template with two classes 
template<class T1, class T2> T1 add(T1 &x, T2 &y)
{
    T1 result = x + y;
    return result;

}


template<class T> class C
{
public:
    T n1 = 5;
    T n2 = 6;
    T add()
    {
        return n1 + n2;
    }

};



void test_overloading()
{

    float x = 0.1, y = 1.1;
    int i = 5;
    C <int> data;


    printf("\n Test overlaoding \n");
    printf("  Max %d\n", myMax<int>(3, 7));
    printf("  Max %f\n", myMax<double>(3.0, 7.0));
    printf("  Max %c\n", myMax<char>('g', 'e'));
    printf("  Max %f\n", max<double>(1.0, 0.1));

// overloading: generic programming 
   printf("  add %f\n", add(x, y));
   printf("  add %f\n", add(x, i));


// Classes 
   printf("  add %d\n", data.add());



}

