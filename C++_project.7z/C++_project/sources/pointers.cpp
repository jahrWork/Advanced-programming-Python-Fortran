// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


//#include <iostream>

//#include <vector>

//#include "./EIGENDIR/Eigen/Dense"
//
//using namespace std;
//
//using Eigen::VectorXd; 
//using Eigen::MatrixXd;
//using Eigen::Map;
//
//int pointers()
//{
//    MatrixXd m(2, 2);
//    m(0, 0) = 3;
//    m(1, 0) = 2.5;
//    m(0, 1) = -1;
//    m(1, 1) = m(1, 0) + m(0, 1);
//    std::cout << m << std::endl;
//
//    m = 2 * m; 
//
//    std::cout << m << std::endl;
//
//    VectorXd M1(6);    // Column-major storage
//
//
//    M1 << 1, 2, 3, 4, 5, 6;
//
//
//    Map<MatrixXd> M2(M1.data(), 3, 2);
//    cout << "M2:" << endl << M2 << endl;
//
//    M1 = 2 * M1; 
//
//    cout << "M2:" << endl << M2 << endl;
//
//    return 0; 
//}

 
#include "pointers.h"




// Array of abstract types 
template<class T, int size> class arr
{
    T x[size];           // automatic array initialization.  
};


// array of polymorphic pointers 
template <class T> T *p[5];




void test_pointers()
{
    float x = 0.1, y = 1.1;
    int i, j = 5;
  

    arr<double, 20> v; // array of size 20 of doubles 
    float *pf[5];      // array of float by means of pointers 
    char c = 'A';


    pf[0] = &x; // point to a float 
    pf[1] = &y; // point to a float 

    printf("\n Array of floats pointed to floats: x,y \n");
    for(i=0; i<2; i++)
        printf("  pf[%d]=%f\n", i, *pf[i]);
    

    printf("\n Array of polymorphic pointers \n");
    printf(" pointed to: float, integer, char \n");
    p<float>[0] = &x; // point to a float 
    p<int>[1] = &j;   // point to an integer 
    p<char>[2] = &c;  // point to a character 

    printf("   p[0]=%f\n", *p<float>[0]);
    printf("   p[1]=%d\n", *p<int>[1]);
    printf("   p[2]=%c\n", *p<char>[2]);
       

}