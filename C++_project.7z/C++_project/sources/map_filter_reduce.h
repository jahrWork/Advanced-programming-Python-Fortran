
using namespace std;
#include <iostream> 
#include <string> 
#include <algorithm>
#include <vector>


void test_map_filter_reduce(); 
