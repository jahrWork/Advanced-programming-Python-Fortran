
#include <stdio.h>     
#include <functional> // function objects 

using std::function;


void test_overloading(); 
