#include <stdio.h>     
#include <math.h>     
#include <functional> // function objects 

using std::function;
using namespace std;

void function_examples(); 