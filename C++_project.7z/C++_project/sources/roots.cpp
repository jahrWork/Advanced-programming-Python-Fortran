// Operators are overloaded in <complex> library for complex numbers 
#include <iostream>   
#include <complex>       
using namespace std;
#include "roots.h" 

void roots()
{
      
    complex<float> a=1, b=1, c=1; // coefficients 
    complex<float> f=4, d=2;      // factors 4 and 2 must be defined as complexes
                                  // because  * is not overloaded in this library 
                                  // with integer, complex 
    
    complex<float> x1, x2;
    
    cout << "  Roots of a x**2 + b* x + c = 0 " << endl;

    x1 = ( -b + sqrt( pow(b, 2) - f*a*c) )/(d*a); 
    x2 = ( -b - sqrt( pow(b, 2) - f*a*c) )/(d*a);
   
    cout <<"    x1: " << x1 << endl;
    printf("    x2:%f %f\n\n", real(x2), imag(x2)); 
   

}