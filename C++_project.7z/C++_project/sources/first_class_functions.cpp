

#include "first_class_functions.h"


double f(double x) {

    return 1 / (1 + x); 
}

double Integral( double a, double b, function <double(double x)> f ) 
{

    return ( f(a) + f(b) )/2;
}

double Moment(double a, double b, int n, function <double(double x)> f ) 
{
  
    // lambda function 
    // auto : gives automatically  the type of g 
    // [ ] is used to take into account the environment ( n and f(x) ) 

    auto g = [&](double x) {  return  pow(x, n) * f(x); }; 

    return Integral(a, b, g);

}





void function_examples()
{
   
    printf("\n First class function examples\n");

    printf("  Integral of f  %f\n", Integral(.0, 2.0, f));

    printf("  Moment of f order n  %f\n", Moment(.0, 2.0, 3, f));

   
}





