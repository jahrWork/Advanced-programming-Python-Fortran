
#include "map_filter_reduce.h"


int str_to_int(string str) { return stoi(str); }
    
bool my_filter(int s) { return s <= 111; }

   

void test_map_filter_reduce() {

    vector<string> sp{ "123", "111", "444" };
    vector<int> v(3);
    int i; 

    transform( sp.begin(), sp.end(),  v.begin(), str_to_int ); 
    
    printf("\n Array of strings = "); 
    for (i = 0; i < 3; i++) printf("%s ", sp[i].c_str()); 
    
    printf("\n Array of integers = ");
    for (i = 0; i < 3; i++) printf("%d ", v[i]);
    
    auto it = remove_if( v.begin(), v.end(), my_filter ); 
     
    v.erase( it, v.end());

    printf("\n Array of filtered integers = %d %d", v[0], v[1]);
           
}




    
