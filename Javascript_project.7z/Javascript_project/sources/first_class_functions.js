'use strict';


function Integral(a, b, f) {

    return ( f(a) + f(b) )/2 
}

function Moment(a, b, n, f) {

    function g(x) {
        return x**n * f(x) 
    }
    return Integral(a, b, g)
}

function f(x) {

    return 1 / (1 + x); 
}

console.log('Moment=', Moment(0., 2., 3, f) );
