'use strict';
// Javascript is a class-less language. 
// Everything is an object 
// Objects inherit from other objects (no class to class) 


var figure = { }
figure.F = 1000
figure.area = function() { return this.F; }

var line = Object.create(figure); 
line.L = 5
line.area = function(){ return this.L + this.F }

var square = Object.create(figure); 
square.S = 4
square.area = function(){ return this.S**2 + this.F }

var Figures = [ line, square, line, figure ]; 

var A = 0 
for( var i= 0; i< Figures.length; i++) A = A + Figures[i].area()

console.log(' Total area =', line.area() + square.area() + line.area() + figure.area());
console.log(' Figures Total area =', A);


// This a more elegant way to emulate classes
// constructors to instatiate objects 
function Figure( F ) 
{
  this.F = F; 
  this.area =  function() { return this.F; }
}

function Line( F, L ) 
{
  Figure.call(this, F);
  this.L= L; 
  this.area =  function() { return this.L + this.F; }
}

function Square( F, S ) 
{
  Figure.call(this, F);
  this.S= S; 
  this.area =  function() { return this.S**2 + this.F; }
}

// when this module is required (require), 
// everything is private but the exported functions. 
exports.polymorphism = function(){

    var F1 = new Figure(1000); 
    var L1 = new Line( 1000, 5); 
    var S1 = new Square( 1000, 4); 

    var Figures = [ L1, S1, L1, F1 ]; 

    var A = 0 
    for( var i= 0; i< Figures.length; i++) A += Figures[i].area()

    console.log(' Total area =', line.area() + square.area() + line.area() + figure.area());
    console.log(' Figures Total area =', A);

}