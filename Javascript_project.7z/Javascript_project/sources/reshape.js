'use strict';
Array.prototype.reshape = function (rows, cols) {
    var copy = this.slice(0); // Copy all elements.
    this.length = 0; // Clear out existing array.

    for (var r = 0; r < rows; r++) {
        var row = [];
        for (var c = 0; c < cols; c++) {
            var i = r * cols + c;
            if (i < copy.length) {
                row.push(copy[i]);
            }
        }
        this.push(row);
    }
};


var U = new Array(8);

U = [1, 1, 1, 1, 1, 1, 1, 1];
U[0] = 0;   
//var A = U; 
var V = U.slice(0, 4)
V.reshape(2, 2); 


//V[0][1] = -1; 

//A[0][1] = 0; 

//console.log('A =', A);
console.log('U =', U);
console.log('V =', V);

