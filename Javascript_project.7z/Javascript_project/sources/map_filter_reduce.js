﻿

function str_to_number(str) {

    return parseInt(str);
}

function max(a, b) {

    return Math.max(a, b);
}

function my_filter(a) {

    return a > 120;
}


var sp = ["123", "111", "444"];

exports.test_map_filter_reduce =  function () {

    var map = sp.map(str_to_number);
    var filter = map.filter(my_filter); 
    var reduce = map.reduce(max)

    console.log(" array of strings = ", sp);
    console.log(" MAP: array of numbers = ", map);
    console.log(" FILTER: filtered array = ", filter);
    console.log(" REDUCE: max value = ", reduce);
}