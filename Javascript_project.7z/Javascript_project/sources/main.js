'use strict';

const { roots } = require('./roots.js')
const { polymorphism } = require('./polymorphism.js')
const { test_map_filter_reduce } = require('./map_filter_reduce.js')

roots();

polymorphism();

test_map_filter_reduce();


