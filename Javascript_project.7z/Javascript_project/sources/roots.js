'use strict';


// Operator overloading is not possible in Javascript 
const { sqrt, complex, add, multiply } = require('mathjs')


exports.roots = function(){

  var a = 1, b = 1, c = 1; 
  var x1, x2;  // roots 
  var d;       // discriminant
  var f;       // denominator 

  console.log("Roots of a x**2 + b* x + c = 0 ");

  d = sqrt(b**2-4*a*c); 
  f = complex(2*a, 0).inverse(); 

  x1 = multiply( add( -b,  d), f );   
  x2 = multiply( add( -b,  d.neg()), f );   

  console.log('x1 =', x1, 'x2 =', x2);

}; 


